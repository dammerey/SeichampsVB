package fr.dammerey.seichampsvb.data


import kotlin.collections.sortBy
import kotlin.system.exitProcess

data class Equipe(var nom: String){

    private var listeJoueurs : MutableList<Joueur> = mutableListOf<Joueur>()

    fun ajouterJoueur(joueur : Joueur){
        listeJoueurs.add(joueur)
        this.trierEquipe()
    }
    fun supprimerJoueur(joueur : Joueur): Boolean{
        return listeJoueurs.removeIf{it.Nom == joueur.Nom && it.prenom == joueur.prenom}
    }
    fun modifierJoueur(joueur : Joueur){
        if(supprimerJoueur(joueur)){
            listeJoueurs.add(joueur)
            this.trierEquipe()
        }
    }
    fun chercherJoueur(nomJoueur : String, prenomJoueur : String): Joueur{

        var joueurChercher = Joueur("","","","","")
        for (joueur in listeJoueurs){
            if (joueur.Nom.lowercase() == nomJoueur.lowercase() && joueur.prenom.lowercase() == prenomJoueur.lowercase()){
                joueurChercher = joueur
            }
        }
        if (joueurChercher.Nom == ""){
            println("Joueur introuvable")
            exitProcess(0)
        }
        else {return joueurChercher}
    }
    fun trierEquipe(){
        listeJoueurs.sortBy { it.Nom }
    }
    fun afficherEquipe(){

        println("Equipe $nom ********")
        for (joueur in listeJoueurs){
            println("${joueur.Nom} ${joueur.prenom}")
            println("Numero de licence : ${joueur.numLicence}")
            println("Telephone : ${joueur.telephone}")
            println("Adresse : ${joueur.adresse} \n")
            println("**************************************************")
        }

    }

    fun getJoueurs(): List<Joueur> {
        return listeJoueurs.toList() // copie pour éviter modification externe
    }

}

fun main(){

    var joueur1 : Joueur = Joueur("Dammerey","Maxime","2545256","06.36.23.25.32","10 allee des bouleaux")
    var joueur2 : Joueur = Joueur("Campaner","Frederique","2545255","06.25.24.12.25","1 rue du roseaux")
    var joueur3 : Joueur = Joueur("Hoche","Bruno","2545254","06.36.23.25.32","103 boulevard Jean Joresse")
    var joueur4 : Joueur = Joueur("OTH","Sophie","254525","06.36.23.23.01","125 rue du marechal Bigeard")

    var listeJoueur : MutableList<Joueur> = mutableListOf(joueur1,joueur2,joueur3,joueur4)


    var equipe1 : Equipe = Equipe("Equipe 1")
    equipe1.ajouterJoueur(joueur1)
    equipe1.ajouterJoueur(joueur2)
    equipe1.ajouterJoueur(joueur3)

    equipe1.ajouterJoueur(joueur4)

    equipe1.afficherEquipe()

    println("****** Ajouter un joueur Gabriel **********")
    equipe1.ajouterJoueur(
        Joueur("Dammerey","Gabriel","25145254","06.45.26.25.32","10 allee des Bouleaux")
    )
    equipe1.afficherEquipe()

    var chercheJoueur : Joueur
    println("****** Recherche d'un joueur **********")
    chercheJoueur =equipe1.chercherJoueur("dammerey","Maxime")
    if(chercheJoueur.Nom != "") {
        println("joueur trouvé")
        chercheJoueur.AfficheJoueur()
        chercheJoueur.telephone = "01.23.36.53.62"
        equipe1.modifierJoueur(chercheJoueur)
        println("Joueur modifié")
        chercheJoueur.AfficheJoueur()

    }

}