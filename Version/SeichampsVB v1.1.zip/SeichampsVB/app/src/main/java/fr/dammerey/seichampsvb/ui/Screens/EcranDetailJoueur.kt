package fr.dammerey.seichampsvb.ui.Screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.dammerey.seichampsvb.viewmodel.JoueurViewModel


@Composable
fun EcranDetailJoueur(joueurViewModel: JoueurViewModel, onclicModifierJoueur:()->Unit){

    val joueur = joueurViewModel.JoueurSelectionnee.value
    val context = LocalContext.current


    Card (
        modifier = Modifier
            .fillMaxWidth()

            .padding(15.dp)
            .shadow(15.dp, shape = RoundedCornerShape(5.dp)),

    ){
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(15.dp),
            modifier = Modifier
                .fillMaxWidth()
               // .shadow(15.dp, shape = RoundedCornerShape(5.dp))


               // .padding(top = 25.dp)



        ) {
            Text(
                text = "${joueur?.Nom}   ${joueur?.prenom}",
                fontSize = 35.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary

            )
            Spacer(modifier= Modifier.height(5.dp))
            Text(
                text = " Numéro Licence : ",
                fontSize = 20.sp
            )
            Text(
                text = "${joueur?.numLicence} ",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier= Modifier.height(3.dp))
            Icon(
                imageVector = Icons.Default.Call,
                contentDescription = "Numero telephone"
            )
            Text(
                text = "${joueur?.telephone}",
                modifier = Modifier
                    .clickable{
                        joueur?.telephone?.let{ //.let permet d'executer une action si la variable n'est pas null (remplace un if (joueur noon null....
                            val intent = Intent(Intent.ACTION_DIAL).apply{
                                val numero = joueur.telephone.replace(".","")
                                data = Uri.parse("tel:$numero") // .parse convertit une chaine de caractère en un objet uri
                            }
                            context.startActivity(intent)
                        }
                    }
                    .padding(start = 5.dp) ,
                textDecoration = TextDecoration.Underline,
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier= Modifier.height(3.dp))
            Icon(
                imageVector = Icons.Default.Home,
                contentDescription = "Adresse Joueur",
                modifier = Modifier.padding(end = 5.dp)
            )
                Text(
                    text = "${joueur?.adresse} ",
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.CenterHorizontally)

                )

        }

        Spacer(modifier = Modifier.height(50.dp))
        /********************* TODO *******************************************/
/*



            Row (
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 25.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ){
                Button(onClick = {}){Text(text="Modifier")}
                Button(onClick = {}){Text(text="Supprimer") }
            }*/
        }
    }

/*
@Preview
@Composable
fun PreviewEcranJoueur(){
    SeichampsVBTheme {
        EcranDetailJoueur(onclicModifierJoueur={})
    }

}*/