package fr.dammerey.seichampsvb.ui.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import fr.dammerey.seichampsvb.ui.Screens.EcranConfig
import fr.dammerey.seichampsvb.ui.Screens.EcranDetailJoueur
import fr.dammerey.seichampsvb.ui.Screens.EcranListJoueur
import fr.dammerey.seichampsvb.ui.Screens.EcranMain
import fr.dammerey.seichampsvb.ui.Screens.EcranPlanning
import fr.dammerey.seichampsvb.ui.Screens.EcranSelectionEquipe
import fr.dammerey.seichampsvb.ui.Screens.SplashScreen
import fr.dammerey.seichampsvb.viewmodel.EquipeViewModel
import fr.dammerey.seichampsvb.viewmodel.JoueurViewModel


@Composable
fun NavGraph(navController: NavHostController, equipeViewModel: EquipeViewModel, joueurViewModel: JoueurViewModel) {
    NavHost(navController = navController, startDestination = "splash") {
        composable("config") {
            EcranConfig(navController= navController)

        }
        composable("splash") {
            SplashScreen(navController= navController)
        }
        composable("selectionEquipe") {

            LaunchedEffect(Unit) {
                equipeViewModel.resetSelection()
            }
            EcranSelectionEquipe(
                equipeViewModel = equipeViewModel,
                onclicEquipe = {
                    navController.navigate("main")
                }
            )
        }
        composable("main") {
            EcranMain(
                equipeViewModel = equipeViewModel,

                onNavigateToPlanning = {
                    navController.navigate("planning")
                },

                onNavigateToListContact = {
                    navController.navigate("listJoueur")
                }
            )
        }
        composable ("listJoueur"){
            EcranListJoueur(
                joueurViewModel = joueurViewModel,
                equipeViewModel = equipeViewModel,
                onClicItemJoueur = {
                    navController.navigate("detailContact")
                }
            )

        }
        composable ("detailContact"){
            EcranDetailJoueur(
                joueurViewModel = joueurViewModel ,
                onclicModifierJoueur = {
                    navController.navigate("detailContact")
                }

            )

        }
        composable ("planning"){

            EcranPlanning(equipeViewModel = equipeViewModel)
        }

    }
}
