package fr.dammerey.seichampsvb.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import fr.dammerey.seichampsvb.data.Equipe
import fr.dammerey.seichampsvb.repository.SeichampsRepository
import fr.dammerey.seichampsvb.repository.SeichampsRepositoryNew


class EquipeViewModel : ViewModel() {

    var equipeSelectionnee by mutableStateOf<Equipe?>(null)

        private set


    private val repository = SeichampsRepository()

    fun selectEquipe(nomEquipe: String) {
        // Recherche ou crée l'équipe à partir du nom
        val equipe = repository.getEquipeByName(nomEquipe)
        if(equipe != null) {
            Log.d("Ecran", "EquipeViewModel - Equipe sélectionnée: ${equipe?.nom}")
            equipeSelectionnee = equipe
        }
        else
        {
            Log.d("Ecran", "EquipeViewModel - Equipe non trouvée")
        }
    }

    fun chargerEquipe1() {
        equipeSelectionnee = repository.getEquipe1()
    }

    fun chargerEquipe2() {
        equipeSelectionnee = repository.getEquipe2()
    }
    fun resetSelection() {
        equipeSelectionnee = null
    }
}