package fr.dammerey.seichampsvb.data

data class MatchInfo(
    val position: String,
    val nomEquipe: String,
    val score: String
)
