package fr.dammerey.seichampsvb.ui.Screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MaterialTheme.typography
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import fr.dammerey.seichampsvb.R
import fr.dammerey.seichampsvb.util.ConfigManager
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(navController: NavController) {
    var startAnimation by remember { mutableStateOf(false) }
    var context = LocalContext.current
    val scale by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.5f,
        animationSpec = tween(1000, easing = FastOutSlowInEasing),
        label = "scaleAnim"
    )

    val alpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(1000),
        label = "alphaAnim"
    )

    ConfigManager.init(context)


    LaunchedEffect(Unit) {
        startAnimation = true
        delay(3000)
        navController.navigate("selectionEquipe") {
            popUpTo("splash") { inclusive = true } // on supprime l’écran splash du backstack
        }
    }

    Box(

        modifier = Modifier
            .fillMaxSize()
            .background(
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                shape = MaterialTheme.shapes.medium
            ),
        contentAlignment = Alignment.Center
    )
    {
        Column (
            horizontalAlignment = Alignment.CenterHorizontally,



        ){
            Text(
                text = "Seichamps Volley-Ball",
                style = typography.headlineLarge,
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 40.sp,
               // modifier = Modifier.alpha(alpha).scale(scale)


            )
            Spacer(modifier = Modifier.height(150.dp) )
            Image(
                painter = painterResource(id = R.drawable.logo_sechamps), // mets ici ton image/logo
                contentDescription = "Logo Seichamps VB",
                modifier = Modifier
                    .size(200.dp)
                    .alpha(alpha)
                    .scale(scale)
            )
            Spacer(modifier = Modifier.height(150.dp) )
            Text(
                text = "@Dammerey.fr - 08.2025 - Version 1.1",
                style = typography.headlineLarge,
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 15.sp,
                // modifier = Modifier.alpha(alpha).scale(scale)
            )
        }
    }
}