package fr.dammerey.seichampsvb.repository

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.gson.Gson
import fr.dammerey.seichampsvb.data.Equipe
import fr.dammerey.seichampsvb.util.AppParams
import fr.dammerey.seichampsvb.util.ConfigManager
import java.io.File
import java.io.FileReader
import kotlin.jvm.java


class SeichampsRepositoryNew : SeichampsRepositoryInterface {

    private val gson = Gson()
    private var equipe1 : Equipe? = null
    private var equipe2 : Equipe? = null

  //verifie si les fichiers json des deux equipes existe sinon les copies de Asset vers le repertoire interne de l'application
    fun initEquipes(context: Context){
        var appContext = context.applicationContext
        val fileEquipe1 = File(appContext.filesDir, AppParams.nom_EQUIPE1 + ".json")
        val fileEquipe2 = File(appContext.filesDir, AppParams.nom_EQUIPE2 + ".json")
        if(!fileEquipe1.exists())
        {
          ConfigManager.copyAssetToInternalStorage(appContext, AppParams.nom_EQUIPE1 + ".json")
        }
        if(!fileEquipe2.exists())
        {
          ConfigManager.copyAssetToInternalStorage(appContext, AppParams.nom_EQUIPE2 + ".json")
        }
        try {
            FileReader(fileEquipe1).use { equipe1 = gson.fromJson(it, Equipe::class.java) }
            FileReader(fileEquipe2).use { equipe2 = gson.fromJson(it, Equipe::class.java) }
            Log.d("Repository", "Équipes chargées avec succès")
        } catch (e: Exception) {
            Log.e("Repository", "Erreur lors de la lecture du fichier JSON", e)
            Toast.makeText(
                context,
                "$e : erreur lors de la lecture du fichier JSON",
                Toast.LENGTH_SHORT
            ).show()
        }
    }


    override fun getEquipe1() : Equipe{
        return equipe1?: throw IllegalStateException("Equipe1 non initialisée")
    }
    override fun getEquipe2() : Equipe{
        return equipe2?: throw IllegalStateException("Equipe2 non initialisée")

    }
    override fun getEquipeByName(nom: String): Equipe?{
        return when (nom) {
            AppParams.nom_EQUIPE1 -> getEquipe1()
            AppParams.nom_EQUIPE2 -> getEquipe2()
            else -> null
        }
    }
}





