package fr.dammerey.seichampsvb.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import fr.dammerey.seichampsvb.data.Joueur

class JoueurViewModel : ViewModel(){

    var JoueurSelectionnee = mutableStateOf<Joueur?>(null)  // mutableStateOf permet de rendre observable les changement dans Equipe et de recomposer
    // la variable a deux etat soit null (?) soit Equipe

 /*   fun getJoueurSelectionner() : Joueur? {
        return JoueurSelectionnee
    }*/
}