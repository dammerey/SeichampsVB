package fr.dammerey.seichampsvb.repository

import fr.dammerey.seichampsvb.data.Equipe
import fr.dammerey.seichampsvb.data.Joueur
import fr.dammerey.seichampsvb.util.AppParams

class SeichampsRepository : SeichampsRepositoryInterface {

    override fun getEquipe1() : Equipe{
        val equipe = Equipe(AppParams.nom_EQUIPE1)
        equipe.ajouterJoueur(Joueur("Dammerey","Maxime","1 900 004","06.48.76.42.59", "10 allée des Bouleaux,\n 544420 Saulxures-Les-Nancy"))
        equipe.ajouterJoueur(Joueur("Campaner","Frederic", "1 857 047","06.63.63.33.21","20 chemin du petit étang,\n 54110 Buissoncourt"))
        equipe.ajouterJoueur(Joueur("Chollot","Nicolas","1 408 658","06.73.11.13.16","10 allée des Pinsons,\n 54280 Seichamps"))
        equipe.ajouterJoueur(Joueur("Chalon","Benjamin","1 814 755","06.87.80.38.76","1 rue RPre,\n 54280 velaine-Sous-Amence"))
        equipe.ajouterJoueur(Joueur("Milnis","Vincent","1 805 279","06.09.98.18.20","18 Avenue de l'Europe,\n 54280 Seichamps"))
        equipe.ajouterJoueur(Joueur("Pons Bosch","Bartomeu","2 281 917","07.68.55.29.34","Inconnue"))
        equipe.ajouterJoueur(Joueur("Seigneur","Eloi","1 768 247","06.43.18.21.39","18 Allée Francois Flageollet,\n54270 Essey-Les-Nancy"))
        equipe.ajouterJoueur(Joueur("Carnin","Charles","1 835 790","06.83.75.11.73","19 rue Jean Ferrat,\n 54510 Tomblaine"))
        equipe.ajouterJoueur(Joueur("Chollot","Clement","1953511","06.77.12.00.77","62 rue Saint Georges,\n 54000 Nancy"))
        equipe.ajouterJoueur(Joueur("Grare","David","2250332","06.06.76.98.11","1 Grand Rue,\n 54000 Nancy"))

        return equipe
    }
    override fun getEquipe2() : Equipe{
        val equipe = Equipe(AppParams.nom_EQUIPE2)
        equipe.ajouterJoueur(Joueur("Genin","Laurent","1997517","06.74.74.41.67", "106 rue des Parterres Fleuris,\n 54280 Seichamps"))
        equipe.ajouterJoueur(Joueur("Guillaume","Remi", "2700301","06.31.39.59.77","1 avenue du Quebec,\n 54280 Seichamps"))
        equipe.ajouterJoueur(Joueur("Marchal","Eric","2702640","06.86.54.10.57","92 avenue de la République,\n 54520 Laxou"))
        equipe.ajouterJoueur(Joueur("Marchal","Laurence","955639","06.75.93.57.40","5 rue d'Auvergne,\n 54425 Pulnoy"))
        equipe.ajouterJoueur(Joueur("Reihl","Maîa","1871271","06.67.72.59.00","104 rue Jeanne d'Arc,\n 54280 Seichamps"))
        equipe.ajouterJoueur(Joueur("Soto Gutierrez","Stéphanie","2502972","07.60.85.00.27","18 rue Pablo Picasso,\n 54510 Tomblaine"))
        equipe.ajouterJoueur(Joueur("Ternat","Guillaume","2690821","06.72.60.77.09","2 rue Johannes Gutenber,\n 54420 Pulnoy"))
        equipe.ajouterJoueur(Joueur("Wimmer","Emeric","2795308","07.70.38.54.77","19 rue du Neuf Chemin,\n 54420 Saulxures-Les-Nancy"))
        equipe.ajouterJoueur(Joueur("Da Silva","Marie","2592579","06.21.99.17.33","3 rue de Verdun,\n 54270 Essey-Les-Nancy"))
        equipe.ajouterJoueur(Joueur("Cousseran","Francois","1118097","","3 rue Clément Ader,\n 54420 Saulxures-Les-Nancy"))
        equipe.ajouterJoueur(Joueur("Courtois","Guillaume","2691506","06.79.45.55.85","4 rue Blaise Pascal,\n 54280 Seichamps"))

        return equipe
    }

    override fun getEquipeByName(nom: String): Equipe? {
        return when (nom) {
            AppParams.nom_EQUIPE1 -> getEquipe1()
            AppParams.nom_EQUIPE2 -> getEquipe2()
            else -> null
        }
    }
}